module.exports = {
	groupId: '6083961',
	prefix: '..',
	shoutChannelId: '802603859914129419',
	suggestionChannelId: '800005554495029269',
	shiftChannelId: '803102790909427733',
	trainingChannelId: '803102790909427733',
	colors: {
		BLUE: 3447003,
		RED: 13632027,
		GREEN: 8311585,
		PURPLE: `#5b57d9`,
		YELLOW: 0xffea00,
		LIGHTYELLOW: `#E8E676`,
		BLACK: `#010305`
	},
	memberCount: {
		enabled: "true",
		groupIconURL: 'https://t6.rbxcdn.com/c5b4bd57eb5a94b67d11df608b663238',
		milestones: ['30'],
		memberCountChannelId: '800005335040786442'
	}
}